package store.modal;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class CategoeryList extends ArrayList<Categoery> {

}
