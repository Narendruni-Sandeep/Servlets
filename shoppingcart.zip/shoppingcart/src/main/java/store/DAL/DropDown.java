package store.DAL;

import store.modal.CategoeryList;

public interface DropDown {
	CategoeryList getCategories();
}
