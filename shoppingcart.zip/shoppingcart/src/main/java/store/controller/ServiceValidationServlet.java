package store.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import store.DAL.Common;
import store.DAO.DataBaseBridge;
import store.modal.CartItems;

/**
 * Servlet implementation class ServiceValidationServlet
 */
@WebServlet("/validateservice")
public class ServiceValidationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pincode = request.getParameter("pincode");
		System.out.println(pincode);
		HttpSession hs = request.getSession();
		List<CartItems> items = (ArrayList<CartItems>) hs.getAttribute("cartitems");
		DataBaseBridge dao = new DataBaseBridge();
		Common dal = dao.getCommonDAL();
		ArrayList<String> nonServicableItems = dal.getNonServicableItems(items, pincode);

		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		if (nonServicableItems == null) {
			// If all items are servicable
			out.write("{\"status\":true, \"url\": \"checkout\" }");
		} else {
			// If some items are not servicable
			out.write("{\"status\":false, \"items\":\"" + nonServicableItems + "\"}");
			System.out.println("items are not servicable");
		}

		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
