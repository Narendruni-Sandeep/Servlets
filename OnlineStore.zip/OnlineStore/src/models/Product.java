package models;

public class Product {

	private int productId;
	private String productName;
	private int productCategoryId;
	private int hsnId;
	private String brandName;
	private String imageUrl;
	private int price;

	public Product() {

	}

	public Product(int productId, String productName, int productCategoryId, int hsnId, String brandName,
			String imageUrl, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategoryId = productCategoryId;
		this.hsnId = hsnId;
		this.brandName = brandName;
		this.imageUrl = imageUrl;
		this.price = price;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductCategoryId() {
		return productCategoryId;
	}

	public void setProductCategoryId(int productCategoryId) {
		this.productCategoryId = productCategoryId;
	}

	public int getHsnId() {
		return hsnId;
	}

	public void setHsnId(int hsnCode) {
		this.hsnId = hsnCode;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getPrice() {

		return price;
	}

}
