package models;

public class ProductPrice {

	int productId;
	String batchNumber;
	int price;
	int stockQuantity;
	int mrp;

	public ProductPrice() {

	}

	public ProductPrice(int productId, String batchNumber, int price, int stockQuantity, int mrp) {
		super();
		this.productId = productId;
		this.batchNumber = batchNumber;
		this.price = price;
		this.stockQuantity = stockQuantity;
		this.mrp = mrp;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public int getMrp() {
		return mrp;
	}

	public void setMrp(int mrp) {
		this.mrp = mrp;
	}

}
