package dal;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.ConnectionClass;
import models.Product;

public class ProductListDAL implements ProductsDAO {
	public List<Product> getProducts() {
		List<Product> productList = new ArrayList<>();
		String sql = "SELECT * FROM dhanush_products";
		try {
			ConnectionClass connectionClass = new ConnectionClass();
			Connection conn = connectionClass.getconnectDb();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			// Iterate over the result set and create Product objects
			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt("prod_id"));
				product.setProductName(rs.getString("prod_title"));
				product.setProductCategoryId(rs.getInt("prod_prct_id"));
				product.setHsnId(rs.getInt("prod_hsnc_id"));
				product.setBrandName(rs.getString("prod_brand"));
				product.setImageUrl(rs.getString("prod_image"));
				product.setPrice(rs.getInt("prod_price"));
				productList.add(product);
			}

		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return productList;
	}

	public List<Product> getProductsByPage(int page, int pageSize, int offset) {
		List<Product> productList = new ArrayList<>();
		String sql = "SELECT * FROM dhanush_products LIMIT " + pageSize + " OFFSET " + offset;
		try {
			ConnectionClass connectionClass = new ConnectionClass();
			Connection conn = connectionClass.getconnectDb();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			// Iterate over the result set and create Product objects
			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt("prod_id"));
				product.setProductName(rs.getString("prod_title"));
				product.setProductCategoryId(rs.getInt("prod_prct_id"));
				product.setHsnId(rs.getInt("prod_hsnc_id"));
				product.setBrandName(rs.getString("prod_brand"));
				product.setImageUrl(rs.getString("prod_image"));
				product.setPrice(rs.getInt("prod_price"));
				productList.add(product);
			}

		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return productList;
	}

}
