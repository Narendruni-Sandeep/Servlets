package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.ConnectionClass;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/fetchProductsByCategory")
public class FetchProductsByCategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int selectedCategory = Integer.parseInt(request.getParameter("category"));
        String productsHtml = "";
        try {
            ConnectionClass connectionClass = new ConnectionClass();
            Connection connection = connectionClass.getconnectDb();
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM dhanush_products WHERE prod_prct_id = ?");
            preparedStatement.setInt(1, selectedCategory);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                productsHtml += "<div class='product'>";
                productsHtml += "<img src='" + resultSet.getString("prod_image") + "' alt='" + resultSet.getString("prod_title") + "'>";
                productsHtml += "<div class='product-details'>";
                productsHtml += "<h3>" + resultSet.getString("prod_title") + "</h3>";
                productsHtml += "<p>" + resultSet.getInt("prod_price") + "</p>";
                productsHtml += "<button>Add to Cart</button>";
                productsHtml += "</div>";
                productsHtml += "</div>";
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(productsHtml);
    }
}
