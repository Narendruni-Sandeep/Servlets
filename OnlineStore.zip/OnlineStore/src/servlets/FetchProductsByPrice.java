package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.ConnectionClass;

@WebServlet("/fetchProductsByPrice")
public class FetchProductsByPrice extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int selectedCategory = Integer.parseInt(request.getParameter("category"));
		int selectedPrice = Integer.parseInt(request.getParameter("sortOrder"));

		String productHTML = "";
		try {
			// Establish database connection
			ConnectionClass connectionClass = new ConnectionClass();
			Connection connection = connectionClass.getconnectDb();
			Statement statement;
			ResultSet resultSet;
			statement = connection.createStatement();
			if (selectedCategory == 0) {
				if (selectedPrice == 0) {
					resultSet = statement.executeQuery("SELECT * FROM dhanush_products ORDER BY prod_price ASC");
				} else {
					resultSet = statement.executeQuery("SELECT * FROM dhanush_products ORDER BY prod_price DESC");
				}
			} else {
				if (selectedPrice == 0) {
					resultSet = statement.executeQuery("SELECT * FROM dhanush_products WHERE prod_prct_id = "
							+ selectedCategory + " ORDER BY prod_price ASC");
				} else {
					resultSet = statement.executeQuery("SELECT * FROM dhanush_products WHERE prod_prct_id = "
							+ selectedCategory + " ORDER BY prod_price DESC");
				}
			}
			while (resultSet.next()) {
				// Generate HTML for each product
				productHTML += "<div class='product'>";
				productHTML += "<img src='" + resultSet.getString("prod_image") + "' alt='"
						+ resultSet.getString("prod_title") + "'>";
				productHTML += "<div class='product-details'>";
				productHTML += "<h3>" + resultSet.getString("prod_title") + "</h3>";
				productHTML += "<p>" + resultSet.getDouble("prod_price") + "</p>";
				productHTML += "<button>Add to Cart</button>";
				productHTML += "</div>";
				productHTML += "</div>";
			}
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(productHTML);
	}

}
