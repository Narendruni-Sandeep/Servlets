package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dal.ProductListDAL;
import dal.ProductsDAO;
import models.Product;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in home");

		// Instantiate ProductListDAL as ProductsDAO
		ProductsDAO productsDAO = new ProductListDAL();
		// Retrieve list of products from DAO
		List<Product> productList = productsDAO.getProducts();
		System.out.println(productList.size());

		// Set products attribute in request
		request.setAttribute("productList", productList);
		// PrintWriter out = response.getWriter();
		// out.println("11111111");
		// Forward request to Home.jsp
		RequestDispatcher dispatcher = request.getRequestDispatcher("Home.jsp");
		dispatcher.forward(request, response);

	}

}
