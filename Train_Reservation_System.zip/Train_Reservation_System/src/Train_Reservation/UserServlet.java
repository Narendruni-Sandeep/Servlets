package Train_Reservation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UserController userController;

	public void init() throws ServletException {
		super.init();
		this.userController = new UserController(); // Instantiate the UserController
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action != null) {
			switch (action) {
			case "login":
				handleLogin(request, response);
				break;
			case "register":
				handleRegistration(request, response);
				break;
			default:
				// Handle unsupported action
				break;
			}
		}
	}

	private void handleLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if (userController.loginUser(username, password)) {
			// Login successful, redirect to dashboard or another page
			response.sendRedirect("dashboard.jsp");
		} else {
			// Login failed, redirect back to login page with error message
			response.sendRedirect("login.jsp?error=1");
		}
	}

	private void handleRegistration(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		if (userController.registerUser(username, password, email)) {
			// Registration successful, redirect to login page or another page
			response.sendRedirect("login.jsp?registration=success");
		} else {
			// Registration failed, redirect back to registration page with error message
			response.sendRedirect("register.jsp?error=1");
		}
	}
}
