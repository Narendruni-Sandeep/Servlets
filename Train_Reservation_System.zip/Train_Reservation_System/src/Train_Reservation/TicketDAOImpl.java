// TicketDAOImpl.java
package Train_Reservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TicketDAOImpl implements TicketDAO {
	private Connection connection;

	public TicketDAOImpl() {
		try {
			connection = DbConnection.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
			// Handle connection error
		}
	}

	@Override
	public Ticket getTicketById(int id) throws SQLException {
		String query = "SELECT * FROM tickets WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, id);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					Ticket ticket = new Ticket();
					ticket.setId(resultSet.getInt("id"));
					ticket.setUserId(resultSet.getInt("user_id"));
					ticket.setTrainId(resultSet.getInt("train_id"));
					ticket.setSourceStationId(resultSet.getInt("source_station_id"));
					ticket.setDestinationStationId(resultSet.getInt("destination_station_id"));
					ticket.setTravelDate(resultSet.getString("travel_date"));
					ticket.setClassType(resultSet.getString("class_type"));
					ticket.setFare(resultSet.getDouble("fare"));
					return ticket;
				}
			}
		}
		return null; // Return null if ticket not found
	}

	@Override
	public List<Ticket> getAllTickets() throws SQLException {
		List<Ticket> tickets = new ArrayList<>();
		String query = "SELECT * FROM tickets";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery()) {
			while (resultSet.next()) {
				Ticket ticket = new Ticket();
				ticket.setId(resultSet.getInt("id"));
				ticket.setUserId(resultSet.getInt("user_id"));
				ticket.setTrainId(resultSet.getInt("train_id"));
				ticket.setSourceStationId(resultSet.getInt("source_station_id"));
				ticket.setDestinationStationId(resultSet.getInt("destination_station_id"));
				ticket.setTravelDate(resultSet.getString("travel_date"));
				ticket.setClassType(resultSet.getString("class_type"));
				ticket.setFare(resultSet.getDouble("fare"));
				tickets.add(ticket);
			}
		}
		return tickets;
	}

	@Override
	public List<Ticket> getTicketsByUserId(int userId) throws SQLException {
		List<Ticket> tickets = new ArrayList<>();
		String query = "SELECT * FROM tickets WHERE user_id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, userId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					Ticket ticket = new Ticket();
					ticket.setId(resultSet.getInt("id"));
					ticket.setUserId(resultSet.getInt("user_id"));
					ticket.setTrainId(resultSet.getInt("train_id"));
					ticket.setSourceStationId(resultSet.getInt("source_station_id"));
					ticket.setDestinationStationId(resultSet.getInt("destination_station_id"));
					ticket.setTravelDate(resultSet.getString("travel_date"));
					ticket.setClassType(resultSet.getString("class_type"));
					ticket.setFare(resultSet.getDouble("fare"));
					tickets.add(ticket);
				}
			}
		}
		return tickets;
	}

	@Override
	public boolean addTicket(Ticket ticket) throws SQLException {
		String query = "INSERT INTO tickets (user_id, train_id, source_station_id, destination_station_id, travel_date, class_type, fare) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, ticket.getUserId());
			preparedStatement.setInt(2, ticket.getTrainId());
			preparedStatement.setInt(3, ticket.getSourceStationId());
			preparedStatement.setInt(4, ticket.getDestinationStationId());
			preparedStatement.setString(5, ticket.getTravelDate());
			preparedStatement.setString(6, ticket.getClassType());
			preparedStatement.setDouble(7, ticket.getFare());
			int rowsInserted = preparedStatement.executeUpdate();
			return rowsInserted > 0;
		}
	}

	@Override
	public boolean updateTicket(Ticket ticket) throws SQLException {
		String query = "UPDATE tickets SET user_id = ?, train_id = ?, source_station_id = ?, destination_station_id = ?, travel_date = ?, class_type = ?, fare = ? WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, ticket.getUserId());
			preparedStatement.setInt(2, ticket.getTrainId());
			preparedStatement.setInt(3, ticket.getSourceStationId());
			preparedStatement.setInt(4, ticket.getDestinationStationId());
			preparedStatement.setString(5, ticket.getTravelDate());
			preparedStatement.setString(6, ticket.getClassType());
			preparedStatement.setDouble(7, ticket.getFare());
			preparedStatement.setInt(8, ticket.getId());
			int rowsUpdated = preparedStatement.executeUpdate();
			return rowsUpdated > 0;
		}
	}

	@Override
	public boolean deleteTicket(int id) throws SQLException {
		String query = "DELETE FROM tickets WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, id);
			int rowsDeleted = preparedStatement.executeUpdate();
			return rowsDeleted > 0;
		}
	}
}
