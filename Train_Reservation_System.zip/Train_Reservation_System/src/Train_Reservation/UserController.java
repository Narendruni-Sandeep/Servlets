// UserController.java
package Train_Reservation;

import java.sql.SQLException;

public class UserController {
	private UserDAO userDAO;

	public UserController() {
		this.userDAO = new UserDAOImpl(); // Instantiate the UserDAO implementation
	}

	public boolean loginUser(String username, String password) {
		try {
			User user = userDAO.getUserByUsername(username);
			if (user != null && user.getPassword().equals(password)) {
				// User authenticated successfully
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			// Handle database error
		}
		// Authentication failed
		return false;
	}

	public boolean registerUser(String username, String password, String email) {
		try {
			// Check if user already exists
			if (userDAO.getUserByUsername(username) != null) {
				// User with this username already exists
				return false;
			}
			// Create a new User object
			User newUser = new User(username, password, email);
			// Add the user to the database
			return userDAO.addUser(newUser);
		} catch (SQLException e) {
			e.printStackTrace();
			// Handle database error
		}
		// Registration failed
		return false;
	}
}
