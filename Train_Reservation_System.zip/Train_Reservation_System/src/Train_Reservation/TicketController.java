// TicketController.java
package Train_Reservation;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/TicketController")
public class TicketController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private TicketDAO ticketDAO; // Assuming you have a TicketDAO implementation

	public void init() {
		// Initialize TicketDAO instance
		ticketDAO = new TicketDAOImpl(); // Replace with your actual implementation
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Display all booked tickets for the current user
		HttpSession session = request.getSession();
		int userId = (int) session.getAttribute("userId"); // Assuming userId is stored in session
		List<Ticket> bookedTickets = null;
		try {
			bookedTickets = ticketDAO.getBookedTicketsByUserId(userId);
		} catch (DAOException e) {
			// Handle exception
			e.printStackTrace();
		}
		request.setAttribute("bookedTickets", bookedTickets);
		request.getRequestDispatcher("booked_tickets.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Book a new ticket
		HttpSession session = request.getSession();
		int userId = (int) session.getAttribute("userId"); // Assuming userId is stored in session
		int trainId = Integer.parseInt(request.getParameter("trainId"));
		String passengerName = request.getParameter("passengerName");
		String seatNumber = request.getParameter("seatNumber");

		// Create a new ticket and add it to the database
		Ticket ticket = new Ticket(trainId, userId, passengerName, seatNumber);
		try {
			ticketDAO.bookTicket(ticket);
		} catch (DAOException e) {
			// Handle exception
			e.printStackTrace();
		}

		// Redirect to the GET request to display all booked tickets
		response.sendRedirect(request.getContextPath() + "/TicketController");
	}
}
