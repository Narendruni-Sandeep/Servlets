// Train.java
package Train_Reservation;

public class Train {
	private int id;
	private String name;
	private String source;
	private String destination;

	// Constructors
	public Train() {
	}

	public Train(String name, String source, String destination) {
		this.name = name;
		this.source = source;
		this.destination = destination;
	}

	// Getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	// toString method
	@Override
	public String toString() {
		return "Train [id=" + id + ", name=" + name + ", source=" + source + ", destination=" + destination + "]";
	}
}
