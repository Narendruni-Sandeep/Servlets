// Ticket.java
package Train_Reservation;

public class Ticket {
	private int id;
	private int userId;
	private int trainId;
	private int sourceStationId;
	private int destinationStationId;
	private String travelDate;
	private String classType;
	private double fare;

	// Constructors
	public Ticket() {
	}

	public Ticket(int userId, int trainId, int sourceStationId, int destinationStationId, String travelDate,
			String classType, double fare) {
		this.userId = userId;
		this.trainId = trainId;
		this.sourceStationId = sourceStationId;
		this.destinationStationId = destinationStationId;
		this.travelDate = travelDate;
		this.classType = classType;
		this.fare = fare;
	}

	// Getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getTrainId() {
		return trainId;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public int getSourceStationId() {
		return sourceStationId;
	}

	public void setSourceStationId(int sourceStationId) {
		this.sourceStationId = sourceStationId;
	}

	public int getDestinationStationId() {
		return destinationStationId;
	}

	public void setDestinationStationId(int destinationStationId) {
		this.destinationStationId = destinationStationId;
	}

	public String getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(String travelDate) {
		this.travelDate = travelDate;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	// toString method
	@Override
	public String toString() {
		return "Ticket [id=" + id + ", userId=" + userId + ", trainId=" + trainId + ", sourceStationId="
				+ sourceStationId + ", destinationStationId=" + destinationStationId + ", travelDate=" + travelDate
				+ ", classType=" + classType + ", fare=" + fare + "]";
	}
}
