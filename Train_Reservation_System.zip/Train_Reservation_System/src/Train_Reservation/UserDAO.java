// UserDAO.java
package Train_Reservation;

import java.sql.SQLException;

public interface UserDAO {
	User getUserByUsername(String username) throws SQLException;

	boolean addUser(User user) throws SQLException;
}
