// TrainDAOImpl.java
package Train_Reservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TrainDAOImpl implements TrainDAO {
	private Connection connection;

	public TrainDAOImpl() {
		try {
			connection = DbConnection.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
			// Handle connection error
		}
	}

	@Override
	public Train getTrainById(int id) throws SQLException {
		String query = "SELECT * FROM trains WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, id);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					Train train = new Train();
					train.setId(resultSet.getInt("id"));
					train.setName(resultSet.getString("name"));
					train.setSource(resultSet.getString("source"));
					train.setDestination(resultSet.getString("destination"));
					return train;
				}
			}
		}
		return null; // Return null if train not found
	}

	@Override
	public List<Train> getAllTrains() throws SQLException {
		List<Train> trains = new ArrayList<>();
		String query = "SELECT * FROM trains";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery()) {
			while (resultSet.next()) {
				Train train = new Train();
				train.setId(resultSet.getInt("id"));
				train.setName(resultSet.getString("name"));
				train.setSource(resultSet.getString("source"));
				train.setDestination(resultSet.getString("destination"));
				trains.add(train);
			}
		}
		return trains;
	}

	@Override
	public boolean addTrain(Train train) throws SQLException {
		String query = "INSERT INTO trains (name, source, destination) VALUES (?, ?, ?)";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, train.getName());
			preparedStatement.setString(2, train.getSource());
			preparedStatement.setString(3, train.getDestination());
			int rowsInserted = preparedStatement.executeUpdate();
			return rowsInserted > 0;
		}
	}

	@Override
	public boolean updateTrain(Train train) throws SQLException {
		String query = "UPDATE trains SET name = ?, source = ?, destination = ? WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, train.getName());
			preparedStatement.setString(2, train.getSource());
			preparedStatement.setString(3, train.getDestination());
			preparedStatement.setInt(4, train.getId());
			int rowsUpdated = preparedStatement.executeUpdate();
			return rowsUpdated > 0;
		}
	}

	@Override
	public boolean deleteTrain(int id) throws SQLException {
		String query = "DELETE FROM trains WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, id);
			int rowsDeleted = preparedStatement.executeUpdate();
			return rowsDeleted > 0;
		}
	}
}
