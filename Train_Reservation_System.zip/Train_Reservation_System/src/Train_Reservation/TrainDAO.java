// TrainDAO.java
package Train_Reservation;

import java.sql.SQLException;
import java.util.List;

public interface TrainDAO {
	Train getTrainById(int id) throws SQLException;

	List<Train> getAllTrains() throws SQLException;

	boolean addTrain(Train train) throws SQLException;

	boolean updateTrain(Train train) throws SQLException;

	boolean deleteTrain(int id) throws SQLException;
}
