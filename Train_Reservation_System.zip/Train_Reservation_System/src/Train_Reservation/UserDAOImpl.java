// UserDAOImpl.java
package Train_Reservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAOImpl implements UserDAO {
	private Connection connection;

	public UserDAOImpl() {
		try {
			connection = DbConnection.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
			// Handle connection error
		}
	}

	@Override
	public User getUserByUsername(String username) throws SQLException {
		String query = "SELECT * FROM users WHERE username = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, username);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					User user = new User();
					user.setId(resultSet.getInt("id"));
					user.setUsername(resultSet.getString("username"));
					user.setPassword(resultSet.getString("password"));
					user.setEmail(resultSet.getString("email"));
					return user;
				}
			}
		}
		return null; // Return null if user not found
	}

	@Override
	public boolean addUser(User user) throws SQLException {
		String query = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getEmail());
			int rowsInserted = preparedStatement.executeUpdate();
			return rowsInserted > 0;
		}
	}
}
