// DbConnection.java
package Train_Reservation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	private static final String URL = "jdbc:postgresql://localhost:5432/training";
	private static final String USER = "plf_training_admin"; // Replace with your PostgreSQL username
	private static final String PASSWORD = "pff123"; // Replace with your PostgreSQL password

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}
}
