// StationDAOImpl.java
package Train_Reservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StationDAOImpl implements StationDAO {
	private Connection connection;

	public StationDAOImpl() {
		try {
			connection = DbConnection.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
			// Handle connection error
		}
	}

	@Override
	public Station getStationById(int id) throws SQLException {
		String query = "SELECT * FROM stations WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, id);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					Station station = new Station();
					station.setId(resultSet.getInt("id"));
					station.setName(resultSet.getString("name"));
					station.setCode(resultSet.getString("code"));
					return station;
				}
			}
		}
		return null; // Return null if station not found
	}

	@Override
	public List<Station> getAllStations() throws SQLException {
		List<Station> stations = new ArrayList<>();
		String query = "SELECT * FROM stations";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery()) {
			while (resultSet.next()) {
				Station station = new Station();
				station.setId(resultSet.getInt("id"));
				station.setName(resultSet.getString("name"));
				station.setCode(resultSet.getString("code"));
				stations.add(station);
			}
		}
		return stations;
	}

	@Override
	public boolean addStation(Station station) throws SQLException {
		String query = "INSERT INTO stations (name, code) VALUES (?, ?)";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, station.getName());
			preparedStatement.setString(2, station.getCode());
			int rowsInserted = preparedStatement.executeUpdate();
			return rowsInserted > 0;
		}
	}

	@Override
	public boolean updateStation(Station station) throws SQLException {
		String query = "UPDATE stations SET name = ?, code = ? WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, station.getName());
			preparedStatement.setString(2, station.getCode());
			preparedStatement.setInt(3, station.getId());
			int rowsUpdated = preparedStatement.executeUpdate();
			return rowsUpdated > 0;
		}
	}

	@Override
	public boolean deleteStation(int id) throws SQLException {
		String query = "DELETE FROM stations WHERE id = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, id);
			int rowsDeleted = preparedStatement.executeUpdate();
			return rowsDeleted > 0;
		}
	}
}
