// TicketDAO.java
package Train_Reservation;

import java.sql.SQLException;
import java.util.List;

public interface TicketDAO {
	Ticket getTicketById(int id) throws SQLException;

	List<Ticket> getAllTickets() throws SQLException;

	List<Ticket> getTicketsByUserId(int userId) throws SQLException;

	boolean addTicket(Ticket ticket) throws SQLException;

	boolean updateTicket(Ticket ticket) throws SQLException;

	boolean deleteTicket(int id) throws SQLException;
}
