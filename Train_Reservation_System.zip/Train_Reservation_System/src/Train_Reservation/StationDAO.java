// StationDAO.java
package Train_Reservation;

import java.sql.SQLException;
import java.util.List;

public interface StationDAO {
	Station getStationById(int id) throws SQLException;

	List<Station> getAllStations() throws SQLException;

	boolean addStation(Station station) throws SQLException;

	boolean updateStation(Station station) throws SQLException;

	boolean deleteStation(int id) throws SQLException;
}
