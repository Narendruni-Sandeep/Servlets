package dal;

import models.Customer;

public class Users extends DAL {

	public Users() {
		super();
	}

	public boolean verifyUser(String cemail, String cpassword) {
		boolean ispwd = false;
		try {
			query = "Select cpassword from os_customer where cemail=?";
			st = con.prepareStatement(query);
			st.setString(1, cemail);
			rs = st.executeQuery();
			if (rs.next()) {
				if (cpassword.equals(rs.getString(1))) {
					ispwd = true;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return ispwd;
	}

	public void registerUser(Customer c) {
		// TODO Auto-generated method stub
		query = ("insert into os_customer values(?,?,?,?,?,?);");
		try {

			st = con.prepareStatement(query);
			st.setInt(1, c.getCid());
			st.setString(2, c.getCname());
			st.setString(3, c.getCmobile());
			st.setString(4, c.getCemail());
			st.setString(5, c.getClocation());
			st.setString(6, c.getCpassword());
			st.execute();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
