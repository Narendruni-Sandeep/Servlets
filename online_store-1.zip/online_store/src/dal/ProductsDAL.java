package dal;

import java.sql.Date;

import models.Product;
import models.ProductsList;

public class ProductsDAL extends DAL {

	public ProductsDAL() {
		super();
	}

	public ProductsList getProducts(String category, String sort) {
		// TODO Auto-generated method stub
		ProductsList pl = null;
		System.out.println("from database");
		try {
			query = "SELECT * FROM get_products(?,?);";
			st = con.prepareStatement(query);
			st.setString(1, category);
			st.setString(2, sort);
			rs = st.executeQuery();
			pl = new ProductsList();
			while (rs.next()) {
				pl.add(new Product(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5)));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return pl;
	}

	public void setOrderDetails(int oid, Date sqlDate, int total, int cid) {
		// TODO Auto-generated method stub // TODO Auto-generated method stub
		try {
			query = "Insert into os_orders values(?,?,?,?)";
			st = con.prepareStatement(query);
			st.setInt(1, oid);
			st.setDate(2, sqlDate);
			st.setInt(3, total);
			st.setInt(4, cid);
			st.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public int getCid(String email) {
		int x = 0;
		// TODO Auto-generated method stub
		try {
			query = "Select cid from os_customer where cemail= ?";
			st = con.prepareStatement(query);
			st.setString(1, email);
			rs = st.executeQuery();
			rs.next();
			x = rs.getInt(1);
		} catch (Exception e) {
			System.out.println(e);
		}
		return x;
	}

	public void setProductDetails(int oid, ProductsList p) {
		try {
			query = "insert into os_order_products values(?,?)";
			st = con.prepareStatement(query);
			for (Product pr : p) {
				st.setInt(1, oid);
				st.setInt(2, pr.getPid());
				st.addBatch();
			}
			st.executeBatch();
		} catch (Exception e) {
		}
	}

	public int[] getgst(int[] hsn) {
		// TODO Auto-generated method stub
		int gst[] = new int[hsn.length];
		try {
			int i = 0;
			for (int h : hsn) {
				query = "select gst from os_hsn where hsn_code=?";
				st = con.prepareStatement(query);
				st.setInt(1, h);
				rs = st.executeQuery();
				rs.next();
				gst[i++] = rs.getInt(1);
			}
		} catch (Exception e) {
		}
		return gst;
	}

}
