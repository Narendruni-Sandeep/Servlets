package controllers;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dal.ProductsDAL;
import models.Product;
import models.ProductsList;

/**
 * Servlet implementation class CheckoutServlet
 */
@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CheckoutServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession hs = req.getSession();
		ProductsList p = (ProductsList) hs.getAttribute("cart_items");
		String email = (String) hs.getAttribute("user");
		int oid = (int) Math.random() * (99999 - 10000 + 1) + 10000;
		// String date = new Date().toString();

		long currentTimeMillis = System.currentTimeMillis();

		// Create a java.sql.Date object representing the current date
		Date sqlDate = new Date(currentTimeMillis); // Converts to java.sql.Date
		ProductsDAL pd = new ProductsDAL();
		System.out.println(sqlDate);
		int total = 0;
		int hsn[] = new int[p.size()];
		int i = 0;
		for (Product pr : p) {
			hsn[i] = pr.getHsn();
		}
		int gst[] = pd.getgst(hsn);
		for (Product pr : p) {
			total += (pr.getPrice() + (int) ((double) pr.getPrice() * ((double) gst[i] / (double) 100)));
			System.out.println(total);
			i++;
		}

		int cid = pd.getCid(email);

		pd.setOrderDetails(oid, sqlDate, total, cid);
		pd.setProductDetails(oid, p);
		hs.setAttribute("cart_total", total);
	}

}
